
# The following variables are automatically updated by SVN - do not modify!
RevSVN = '$Revision: 95 $'
DateSVN = '$Date: 2010-07-14 23:53:43 -0500 (Wed, 14 Jul 2010) $'
AuthorSVN = '$Author: hubertley $'

RTE_Revision = int(RevSVN[11:26].strip(' $'))
RTE_Date = DateSVN.split('(')[1].split(')')[0]
RTE_Author = AuthorSVN[9:].strip(' $')

def GetVersion ():
	return RTE_Revision,RTE_Date,RTE_Author

#======== Don't modify any of the code above this line! ========#

__all__ = ( 'MakeRelativePath',
			'MakeAbsolutePath',
			'GetPartitionFilename',
			'LoadCacheFromFile'
			'GetVersion'
			)

import os
import pickle

# This function takes two files as arguments (both must be files, not directories!).
# The file component is stripped off the second file so that the directory remains.
# Then the first file will be made relative to that directory, if at all possible.
# It may be returned as an absolute file reference if it is impossible to turn it
# into a relative reference.
def MakeRelativePath (Filename, ReferenceFile):
	ReferenceDir = os.path.split(ReferenceFile)[0]
	ReferenceDir = os.path.normpath(ReferenceDir).replace('\\','/')
	try:
		RelFilename = os.path.normpath(Filename).replace('\\','/')
		RelFilename = os.path.relpath(RelFilename,ReferenceDir).replace('\\','/')
	except ValueError:
		RelFilename = Filename
	return RelFilename

# This function takes two files as arguments (both must be files, not directories!).
# The file component is stripped off the second file so that the directory remains.
# Then the first file will be made absolute as if it was referenced from that
# working directory.
def MakeAbsolutePath (Filename, ReferenceFile):
	ReferenceDir = os.path.split(ReferenceFile)[0]
	ReferenceDir = os.path.normpath(ReferenceDir).replace('\\','/')
	AbsFilename = os.path.join(ReferenceDir,Filename)
	AbsFilename = os.path.normpath(AbsFilename).replace('\\','/')
	return AbsFilename

# Append the partition file name to the base name given as the first argument.
# The second argument is an integer specifying the partition, e.g. 0=tAA,
# 1=tAB, 2=tAC, and so forth.
def GetPartitionFilename (Filename, Partition):
	NumChars = ord('Z') - ord('A') + 1
	First = int ( Partition / NumChars )
	Second = Partition - ( First * NumChars )
	Filename += '.t'+chr(ord('A')+First)+chr(ord('A')+Second)
	return Filename

# This function loads a cache entry from disk and performs
# some basic checks before returning it
def LoadCacheFromFile (Filename):
	if os.path.exists(Filename):
		try:
			file = open(Filename,'rb')
			Cache = pickle.load(file)
			file.close()
			if 'Marker' in Cache:
				return Cache
			else:
				return None
		except:
			return None
	else:
		return None
