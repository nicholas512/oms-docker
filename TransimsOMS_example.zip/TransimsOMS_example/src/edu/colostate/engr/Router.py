import os
import sys

# @In("String")
BINDIR
# @In("String")
PROJECT

if not hasattr(sys, 'argv'):
    sys.argv  = ['']

sys.path.append(os.path.abspath(PROJECT + '/resources/'))
from TransimsRTE import *


# @Execute
def execute():
    var.BINDIR = BINDIR
    var.PROJECT = PROJECT

    execToCheck = execPlatformCheck("Router")

    if (os.path.exists(var.BINDIR + execToCheck) == False):
        Event ('TRANSIMS Executables not found. Please check paths and try again.')
        sys.exit(1)

    Router = ControlKeys('Router',var.PROJECT + 'data/control/1.Alex.2005.Router.ctl',AllowInvalidKeys=True)
    Router.Run(var.PROJECT + 'data/control_new/Router.ctl')
    return

def execPlatformCheck(execName):
    if (sys.platform == "win32"):
        return execName + ".exe"
    elif (sys.platform == "linux" or sys.platform == "linux2"):
        return execName
    else:
        Event ('Operating system not supported yet')
        sys.exit(1)

    return "Router"
