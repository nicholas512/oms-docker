package edu.colostate.engr.alm;

import org.geotools.coverage.grid.GridCoverage2D;
import org.geotools.coverage.grid.GridCoverageFactory;
import org.geotools.coverage.grid.io.AbstractGridFormat;
import org.geotools.data.DataSourceException;
import org.geotools.data.ows.CRSEnvelope;
import org.geotools.factory.Hints;
import org.geotools.gce.geotiff.GeoTiffFormat;
import org.geotools.gce.geotiff.GeoTiffReader;
import org.geotools.gce.geotiff.GeoTiffWriteParams;
import org.geotools.gce.geotiff.GeoTiffWriter;
import org.geotools.referencing.CRS;
import org.opengis.parameter.GeneralParameterValue;
import org.opengis.parameter.ParameterValueGroup;
import org.opengis.referencing.FactoryException;
import org.opengis.referencing.crs.CoordinateReferenceSystem;
import org.rosuda.REngine.*;
import org.rosuda.REngine.Rserve.RConnection;
import org.rosuda.REngine.Rserve.RserveException;
import org.rosuda.REngine.Rserve.StartRserve;

import oms3.annotations.*;
import java.awt.image.Raster;
import java.io.File;
import java.io.IOException;

/**
 * Created by sidereus on 3/16/17.
 */
public class RasterTransferInput {

    @In
    public String file;

    @Out
    public GridCoverage2D gc;

    @Execute
    public void exec() throws IOException {

        gc = readFile(file);

    }

    private GridCoverage2D readFile(String file) throws IOException {
        File f = new File(file);
        GeoTiffReader reader = new GeoTiffReader(f, new Hints(Hints.FORCE_LONGITUDE_FIRST_AXIS_ORDER, Boolean.TRUE));
        return reader.read(null);
    }

}
