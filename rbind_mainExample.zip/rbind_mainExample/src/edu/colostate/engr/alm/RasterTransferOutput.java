package edu.colostate.engr.alm;

import oms3.annotations.Execute;
import oms3.annotations.In;
import org.geotools.coverage.grid.GridCoverage2D;
import org.geotools.coverage.grid.io.AbstractGridFormat;
import org.geotools.gce.geotiff.GeoTiffFormat;
import org.geotools.gce.geotiff.GeoTiffWriteParams;
import org.geotools.gce.geotiff.GeoTiffWriter;
import org.opengis.parameter.GeneralParameterValue;
import org.opengis.parameter.ParameterValueGroup;

import java.io.File;
import java.io.IOException;

/**
 * Created by sidereus on 3/20/17.
 */
public class RasterTransferOutput {

    @In
    public GridCoverage2D gc;

    @In
    public String file;

    @Execute
    public void exec() throws IOException {

        writeMap(file, gc);

    }

    private void writeMap(String file, GridCoverage2D map) throws IOException {
        GeoTiffWriter writer = new GeoTiffWriter(new File(file + ".tif"));
        GeoTiffWriteParams wp = new GeoTiffWriteParams();
        wp.setCompressionMode(GeoTiffWriteParams.MODE_EXPLICIT);
        wp.setCompressionType("LZW");
        ParameterValueGroup params = new GeoTiffFormat().getWriteParameters();
        params.parameter(AbstractGridFormat.GEOTOOLS_WRITE_PARAMS.getName().toString()).setValue(wp);
        writer.write(map, params.values().toArray(new GeneralParameterValue[1]));
    }

}
