library("raster")

# @In("List<GridCoverage2D>")
rasterList

# @Out("GridCoverage2D")
raster1

# @Out("GridCoverage2D")
raster2

# @Execute
process <- function() {

    raster1 <<- rasterList[[1]]
    raster2 <<- rasterList[[2]]

}
