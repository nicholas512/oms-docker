library("raster")

# @In("GridCoverage2D")
inMap1

# @In("GridCoverage2D")
inMap2

# @Out("CoverageStack")
outStack

# @Execute
process <- function() {

    outStack <<- stack(x=c(inMap1,inMap2))

}
