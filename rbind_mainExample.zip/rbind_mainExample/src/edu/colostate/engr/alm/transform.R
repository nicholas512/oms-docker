library("raster")

# @In("CoverageStack")
rasterStack

# @Out("List<GridCoverage2D>")
rasterList

# @Execute
process <- function() {

    rasterList <<- transform(rasterStack)

}

transform <- function(rasterStack) {
    tmpList <-c()
    for(layer in 1:nlayers(rasterStack)) {
        map <- rasterStack[[layer]]
        map[is.na(map)] <- 0
        tmpList <- c(tmpList, map)
    }
    return(tmpList)
}
